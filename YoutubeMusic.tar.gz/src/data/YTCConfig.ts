export default class YTCConfig {
    public DEBUG: boolean = false;
    public DOWNLOAD: boolean = false;
    public LAST_URL: string = "https://music.youtube.com/"
}